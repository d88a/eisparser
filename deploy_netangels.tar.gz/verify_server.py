
import subprocess
import time
import requests
import sys
import os
import signal

def run_verification():
    print("Starting server for verification...")
    # Start server
    # Use python -m uvicorn to ensure we use the same python env
    cwd = os.path.dirname(os.path.abspath(__file__))
    
    # Assuming we are in D:\Anna\eisparser based on cwd
    # We need to run from project root
    
    server_process = subprocess.Popen(
        [sys.executable, "src/main.py", "server", "--port", "8001"],
        cwd=os.getcwd(),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    
    try:
        print("Waiting for server to start...")
        time.sleep(15) # Wait for startup
        
        if server_process.poll() is not None:
            print("Server failed to start immediately!")
            out, err = server_process.communicate()
            print("STDOUT:", out)
            print("STDERR:", err)
            sys.exit(1)
            
        base_url = "http://127.0.0.1:8001"
        
        # Test 1: GET /
        print(f"Testing GET {base_url}/ ...")
        try:
            resp = requests.get(f"{base_url}/", proxies={"http": None, "https": None})
            print(f"Status: {resp.status_code}")
            if resp.status_code == 200:
                print("Test 1 Passed")
            else:
                print("Test 1 Failed")
                print(resp.text[:200])
        except Exception as e:
            print(f"Connection failed: {e}")

        # Test 2: GET /api/stage1
        print(f"Testing GET {base_url}/api/stage1 ...")
        try:
            resp = requests.get(f"{base_url}/api/stage1?user_id=1", proxies={"http": None, "https": None})
            print(f"Status: {resp.status_code}")
            if resp.status_code == 200:
                data = resp.json()
                print(f"Got {len(data)} items")
                print("Test 2 Passed")
            else:
                print("Test 2 Failed")
                print(resp.text[:200])
        except Exception as e:
            print(f"Connection failed: {e}")

    finally:
        print("Stopping server...")
        server_process.terminate()
        try:
            server_process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            server_process.kill()
        
        
        # Capture remaining output
        try:
             out, err = server_process.communicate(timeout=5)
             print("Server STDOUT:", out)
             print("Server STDERR:", err)
        except:
             pass

if __name__ == "__main__":
    run_verification()
