import sqlite3
import datetime
from pathlib import Path

db_path = "D:/Anna/eisparser/data/eis_data.db"

def inspect_db():
    if not Path(db_path).exists():
        print(f"DB not found at {db_path}")
        return

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    print("--- Zakupki (Top 10 by ROWID DESC) ---")
    cursor.execute("SELECT reg_number, update_date, processed_at, combined_text FROM zakupki ORDER BY rowid DESC LIMIT 10")
    rows = cursor.fetchall()
    
    for row in rows:
        text_len = len(row['combined_text']) if row['combined_text'] else 0
        print(f"Reg: {row['reg_number']}, Date: {row['update_date']}, ProcessedAt: {row['processed_at']}, TextLen: {text_len}")

    print("\n--- Parsing Test ---")
    for row in rows:
        ts = row['processed_at']
        if ts:
            try:
                dt = datetime.datetime.fromisoformat(ts)
                print(f"'{ts}' -> {dt} (OK)")
            except ValueError as e:
                print(f"'{ts}' -> Error: {e}")

    print("\n--- Decisions ---")
    cursor.execute("SELECT * FROM decisions ORDER BY created_at DESC LIMIT 5")
    for row in cursor.fetchall():
        print(dict(row))

    conn.close()

if __name__ == "__main__":
    inspect_db()
